In problem 1, my algorithm is time comsuming, i did not get a good step size for the last question. it is only took 20 iterations. the results is not satisfied enough.

In problem 2, I do not know how to read the data in a elegant way. I have described how i found out the solution. I add them in this zip too.

When I finished all the work. I am still wondering whether my P@1 and P@5 is correct or not. I cannot find any more guildance in the website. In class, I wrote down the note that just count them all and devide by k.

have a nice holiday.

Chan

915490404